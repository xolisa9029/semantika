import pandas as pd
import re
df = pd.read_excel('omonimlar.xlsx')
words = df['omonim'].dropna().str.lower().unique()
with open('tahrir.txt', 'r', encoding='utf-8') as f:
    lines = f.readlines()
for word in words:
    matched_lines = []
    for line in lines:
        clean_line = line.strip().lower()
        if re.search(rf"\b{word}\b", clean_line):
            matched_lines.append(line)
    if matched_lines:
        with open(f"{word}.txt", 'w', encoding='utf-8') as out:
            out.writelines(matched_lines)
