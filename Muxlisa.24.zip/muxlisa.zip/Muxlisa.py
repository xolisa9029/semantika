import re

with open('24.txt', 'r', encoding='utf-8') as f:
    content = f.read()

texts = re.findall(r'"text":\s*"([^"]+)"', content)
p1 = re.findall(r'"paraphrase_1":\s*"([^"]+)"', content)
p2 = re.findall(r'"paraphrase_2":\s*"([^"]+)"', content)

with open('tahrir.txt', 'w', encoding='utf-8') as out:
    for i in range(len(texts)):
        if texts[i].strip().endswith('.'):
            out.write(texts[i] + "\n")
        if i < len(p1) and p1[i].strip().endswith('.'):
            out.write(p1[i] + "\n")
        if i < len(p2) and p2[i].strip().endswith('.'):
            out.write(p2[i] + "\n")
        out.write("")
