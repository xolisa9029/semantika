import pandas as pd
import os

def omonimlarni_fayllarga_ajratish(omonim_fayli, dataset_fayli, natija_papkasi):
    if not os.path.exists(natija_papkasi):
        os.makedirs(natija_papkasi)

    print("Omonimlar ro'yxati tahlil qilinmoqda...")
    omonim_sozlar = set()
    
    try:
        # Excelni o'qiymiz
        df = pd.read_excel(omonim_fayli)
        
        # Barcha ustunlar bo'ylab aylanamiz (A, B, C...)
        for column in df.columns:
            qatorlar = df[column].dropna().astype(str).tolist()
            for soz in qatorlar:
                soz_toza = soz.strip().lower()
                
                # Agar satr raqam bo'lmasa va kamida 2 ta harfdan iborat bo'lsa (so'z bo'lsa)
                if soz_toza and not soz_toza.isdigit() and len(soz_toza) > 1:
                    omonim_sozlar.add(soz_toza)
                    
    except Exception as e:
        print(f"Excel o'qishda xato: {e}")
        return

    if not omonim_sozlar:
        print("Xatolik: Excel fayldan birorta ham so'z (matn) topilmadi!")
        return

    print(f"Jami {len(omonim_sozlar)} ta omonim so'z aniqlandi.")

    # Datasetni o'qish
    try:
        with open(dataset_fayli, 'r', encoding='utf-8') as f:
            gaplar = [line.strip() for line in f if line.strip()]
    except Exception as e:
        print(f"Dataset o'qishda xato: {e}")
        return

    yaratilgan_fayllar_soni = 0

    # Qidiruv va saqlash
    for soz in omonim_sozlar:
        mos_gaplar = [gap for gap in gaplar if gap.lower().startswith(soz)]
        
        if mos_gaplar:
            # Fayl nomidan noqonuniy belgilarni tozalash
            xavfsiz_soz = "".join([c for c in soz if c.isalnum() or c==' ']).strip()
            if not xavfsiz_soz: continue
            
            fayl_nomi = os.path.join(natija_papkasi, f"{xavfsiz_soz}.txt")
            with open(fayl_nomi, 'w', encoding='utf-8') as out_f:
                out_f.write("\n".join(mos_gaplar) + "\n")
            
            yaratilgan_fayllar_soni += 1
            print(f"Fayl yaratildi: {xavfsiz_soz}.txt ({len(mos_gaplar)} ta gap)")

    print(f"\nTayyor! Jami {yaratilgan_fayllar_soni} ta fayl saqlandi.")

# Manzillar (O'zingizga moslang)
omonim_path = r'c:\Users\johon\Desktop\2-semestr\SIA\AI\omonimlar.xlsx'
dataset_path = r'c:\Users\johon\Desktop\2-semestr\SIA\AI\tozalangan_dataset.txt'
result_folder = r'c:\Users\johon\Desktop\2-semestr\SIA\AI\Natijalar'

omonimlarni_fayllarga_ajratish(omonim_path, dataset_path, result_folder)