import json
import re

def katta_faylni_tozalash(kirish_fayli, chiqish_fayli):
    print("Jarayon boshlandi, iltimos kuting...")
    
    with open(kirish_fayli, 'r', encoding='utf-8') as f_in, \
         open(chiqish_fayli, 'w', encoding='utf-8') as f_out:
        
        for qator_raqami, qator in enumerate(f_in, 1):
            qator = qator.strip()
            
            # Agar qator bo'sh bo'lsa yoki faqat verguldan iborat bo'lsa tashlab o'tamiz
            if not qator or qator == ",":
                continue
            
            # Ba'zan qator oxirida ortiqcha vergul keladi (JSON list bo'lsa), shuni tozalaymiz
            if qator.endswith(','):
                qator = qator[:-1]
            
            try:
                # Qatorni JSON ko'rinishida o'qiymiz
                data = json.loads(qator)
                
                # Kalitlarni tartib bilan chiqaramiz
                tartib = ["text", "paraphrase_1", "paraphrase_2"]
                
                for kalit in tartib:
                    if kalit in data and data[kalit]:
                        # Gapni yozamiz va yangi qatorga o'tamiz
                        f_out.write(str(data[kalit]).strip() + "\n")
                
            except json.JSONDecodeError:
                # Agar JSONda xato bo'lsa, regex orqali matnlarni sug'urib olishga urinib ko'ramiz
                # Bu usul qatorda xato bo'lsa ham matnni qutqarib qoladi
                topilgan_gaplar = re.findall(r'":\s*"(.*?)"', qator)
                for gap in topilgan_gaplar:
                    f_out.write(gap.strip() + "\n")
                continue

    print(f"Bajarildi! Barcha gaplar '{chiqish_fayli}' fayliga tartib bilan yozildi.")

# Fayl nomlarini kiriting# Fayl nomlarini to'liq manzili bilan kiriting
katta_faylni_tozalash(r'c:\Users\johon\Desktop\2-semestr\SIA\AI\1.txt', r'c:\Users\johon\Desktop\2-semestr\SIA\AI\tozalangan_dataset.txt')